sap.ui.define([
	"com/Innovation/ui5Project/test/unit/controller/View1.controller"
], function () {
	"use strict";
});