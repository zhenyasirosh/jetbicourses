# Sapui5ListCalendarDragDrop
A project that demonstrate how to drag an item from a list and drop in on a calendar row
